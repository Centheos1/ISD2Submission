/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oms.Model;

/**
 *
 * @author Max.Okura
 */
public class Customer {
    private int id;
    private String firstName;
    private String lastName;
    private String password;
    private String email;
    private String phone;
    private String createDate;
    private int paymentdetailsid;
    private int roleId;

    public Customer() {
    }

    public Customer(int id, String firstName, String lastName, String password, String email, String phone, String createDate, int paymentdetailsid, int roleId) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.createDate = createDate;
        this.paymentdetailsid = paymentdetailsid;
        this.roleId = roleId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public int getPaymentdetailsid() {
        return paymentdetailsid;
    }

    public void setPaymentdetailsid(int paymentdetailsid) {
        this.paymentdetailsid = paymentdetailsid;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    
    
}
